# Change Log

## [1.0.1] 2021-02-10
### Improvements

- Bump UI: [Jinja Argon](https://github.com/app-generator/jinja-argon-dashboard) v1.0.1
- Bump Codebase: [Flask Dashboard](https://github.com/app-generator/boilerplate-code-flask-dashboard) v1.0.4

## [1.0.0] 2020-08-20
### Initial Release

